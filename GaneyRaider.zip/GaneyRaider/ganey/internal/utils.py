from typing import Optional
from rich import print
from functools import cache

import json
import os
import string
import shutil

from discord import Guild, Member # type: ignore


default_data = {
  "token": "",
  "guild_id": 0,
  "pfp_format": "png",
  "purge_old_data": True,
  "download_pfp": True,
  "channel_id": 0
}

@cache

@cache
def check_config_file():
  if not os.path.isfile("config.json"): 
    json.dump(default_data, open("config.json", "w"), indent=2)
    return

  with open("config.json", "r") as file:
    file_data = json.loads(file.read())
  
  required_data = {}

  for key, value in file_data.items():
    if key in default_data.keys():
      required_data[key] = value

  for default_key, default_value in default_data.items():
    if default_key not in required_data.keys():
      required_data[default_key] = default_value

  json.dump(required_data, open("config.json", "w"), indent=2)

class Logger():
  def __init__(self) -> None:
    ...

  def scraper(self, text: str) -> None:
    print(f"")

  def success(self, text: str) -> None:
    print(f"")

  def error(self, text: str) -> None:
    print(f"")

  def custom(self, text: str, header: Optional[str] = None, color: str = "white") -> None:
    print(f"")

@cache
def get_account_settings():
  return json.load(open("config.json"))

@cache
def create_guild_directory(guild: Guild):
  if get_account_settings()["purge_old_data"]:
    shutil.rmtree(f"data/{guild.id}", ignore_errors=True)
  os.makedirs(f"DataScraped/{guild.name}", exist_ok=True)
  open(f"TXTS/{guild.id}.txt", "w").close()

@cache
def clean_string(string_to_clean: str) -> str:
  return "".join([char for char in string_to_clean if char in string.printable])

@cache
async def create_member_file(member: Member):
  if member.bot:
    return

  try:
    guild_id = member.guild.id
    with open(f"TXTS/{guild_id}.txt", "a+") as file:
      file.write(f"{member.id}\n")
  except Exception as e:
    print(f"[bold red][Error] Failed")

@cache
async def download_pfp(member: Member):
  if member.bot or member.avatar is None:
    return
  try:
    data = get_account_settings()
    await member.avatar.save(f"DataScraped/{member.guild.name}/{member.id}.{data['pfp_format']}")
  except Exception as e:
    print(f"Failed 2 save pfps")
