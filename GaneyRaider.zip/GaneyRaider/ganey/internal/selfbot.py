import random
import asyncio  # Import asyncio

from rich.progress import track
from discord import Client, Guild
from internal.utils import get_account_settings, create_guild_directory, create_member_file, download_pfp, Logger

client = Client(chunk_guilds_at_startup=False)
logger = Logger()
print("""Made by Sxvxgee on GitHub (star his repo n follow him, https://github.com/theAbdoSabbagh/DiscordScraper)
      
      """)
async def scrape(conf, guild: Guild):
    members = await guild.fetch_members([random.choice(guild.channels)] if conf["channel_id"] != 0 else conf["channel_id"])
    members = [member for member in members if not member.bot]
    return members

@client.event
async def on_ready():

    config = get_account_settings()
    guild_id = config["guild_id"]

    guild = client.get_guild(int(guild_id))
    members = await scrape(config, guild)

    create_guild_directory(guild)

    for member in track(members, description="Scraping", refresh_per_second=100000):
        await create_member_file(member)

    await client.close()  # Close the client

if __name__ == "__main__":
    config = get_account_settings()
    client.run(config["token"])  # Run the bot
