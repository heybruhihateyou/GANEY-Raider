import json
import random
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import websocket
import asyncio
from colorama import Fore
import ssl

def print_gradient(text, start_color=(255, 255, 255), mid_color=(0, 0, 255), end_color=(255, 255, 255)):
    start_r, start_g, start_b = start_color
    mid_r, mid_g, mid_b = mid_color
    end_r, end_g, end_b = end_color
    length = len(text)

    gradient_text = ""
    for i, char in enumerate(text):
        if i < length / 2:
            # First half: white to dark blue
            progress = i / (length / 2)
            r = int(start_r + (mid_r - start_r) * progress)
            g = int(start_g + (mid_g - start_g) * progress)
            b = int(start_b + (mid_b - start_b) * progress)
        else:
            # Second half: dark blue to white
            progress = (i - length / 2) / (length / 2)
            r = int(mid_r + (end_r - mid_r) * progress)
            g = int(mid_g + (end_g - mid_g) * progress)
            b = int(mid_b + (end_b - mid_b) * progress)

        gradient_text += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    print(gradient_text)

def input_gradient(prompt):
    start_r, start_g, start_b = 255, 255, 255  # White
    mid_r, mid_g, mid_b = 0, 0, 255  # Dark Blue
    end_r, end_g, end_b = 255, 255, 255  # White
    length = len(prompt)

    gradient_prompt = ""
    for i, char in enumerate(prompt):
        if i < length / 2:
            progress = i / (length / 2)
            r = int(start_r + (mid_r - start_r) * progress)
            g = int(start_g + (mid_g - start_g) * progress)
            b = int(start_b + (mid_b - start_b) * progress)
        else:
            progress = (i - length / 2) / (length / 2)
            r = int(mid_r + (end_r - mid_r) * progress)
            g = int(mid_g + (end_g - mid_g) * progress)
            b = int(mid_b + (end_b - mid_b) * progress)

        gradient_prompt += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    return input(gradient_prompt)

def online(token, game, TYPE, STAT, stream_text=None):
    global c
    global l

    ws = websocket.WebSocket()
    ws.connect('wss://gateway.discord.gg/?v=6&encoding=json')
    hello = json.loads(ws.recv())
    heartbeat_interval = hello['d']['heartbeat_interval']
    if TYPE == "Playing":
        gamejson = {
            "name": game,
            "type": 0
        }
    elif TYPE == 'Streaming':
        gamejson = {
            "name": game,
            "type": 1,
            "url": stream_text
        }
    elif TYPE == "Listening":
        gamejson = {
            "name": game,
            "type": 2
        }
    elif TYPE == "Watching":
        gamejson = {
            "name": game,
            "type": 3
        }
    else:
        gamejson = {
            "name": game,
            "type": 0
        }

    auth = {
        "op": 2,
        "d": {
            "token": token,
            "properties": {
                "$os": sys.platform,
                "$browser": "RTB",
                "$device": f"{sys.platform} Device"
            },
            "presence": {
                "game": gamejson,
                "status": STAT,
                "since": 0,
                "afk": False
            }
        },
        "s": None,
        "t": None
    }
    ws.send(json.dumps(auth))
    ack = {
        "op": 1,
        "d": None
    }
    while True:
        time.sleep(heartbeat_interval / 1000)
        try:
            c += 1
            print_gradient(f"{token} Success {c}/{l}", start_color=(0, 255, 0), mid_color=(0, 128, 0), end_color=(0, 255, 0))  # Green gradient
            ws.send(json.dumps(ack))

        except Exception as e:
            print_gradient("Error: " + str(e), start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
            break

TYPE_LIST = ['Playing', 'Streaming', 'Watching', 'Listening']
STAT_LIST = ['online', 'dnd', 'idle']
credits = print_gradient("Made by @ProtDos (https://github.com/ProtDos/Discord-Token-Onliner)   ")
GAME = input_gradient("Status Text   ~   ")
TYPE = TYPE_LIST[int(input_gradient("Type [0-Playing 1-Streaming 2-Watching 3-Listening]   ~   "))]
STAT = STAT_LIST[int(input_gradient("Status [0-Online 1-Do Not Disturb 2-Idle]:   ~   "))]

if TYPE == 'Streaming':
    stream_text = input_gradient("Enter the streaming text: ")
else:
    stream_text = None

with open("TXTS/validtokens.txt", "r") as f:
    al = f.read().split("\n")
    if len(al) <= 1:
        if len(al[0]) <= 10:
            print_gradient("No Tokens Found", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
            exit()
        else:
            print()

c = 0
l = len(al)

with open("TXTS/validtokens.txt", "r") as f:
    al = f.read().split("\n")

l = len(al)

threads = []
for i in range(l):
    t = threading.Thread(target=online, args=(al[i], GAME, TYPE, STAT, stream_text)).start()

print_gradient("Success", start_color=(0, 255, 0), mid_color=(0, 128, 0), end_color=(0, 255, 0))  # Green gradient