from json import loads, dumps
from time import sleep
import time
from websocket import WebSocket
from concurrent.futures import ThreadPoolExecutor
import sys
from os import system
import os
import argparse

coolasstitle = "GANEY"
system("title " + coolasstitle)

def print_gradient(text, start_color=(0, 0, 139), end_color=(0, 0, 139)):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color
    length = len(text)
    
    gradient_text = ""
    for i, char in enumerate(text):
        # Create a gradient that goes dark blue -> white -> dark blue
        if i < length / 2:
            # First half: dark blue to white
            progress = i / (length / 2)
            r = int(start_r + (255 - start_r) * progress)
            g = int(start_g + (255 - start_g) * progress)
            b = int(start_b + (255 - start_b) * progress)
        else:
            # Second half: white to dark blue
            progress = (i - length / 2) / (length / 2)
            r = int(255 - (255 - start_r) * progress)
            g = int(255 - (255 - start_g) * progress)
            b = int(255 - (255 - start_b) * progress)
        
        gradient_text += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    return gradient_text

def gradient_input(prompt):
    print(print_gradient(prompt, (0, 0, 139), (0, 0, 139)), end='', flush=True)
    
    # Capture input character by character
    input_chars = []
    while True:
        char = sys.stdin.read(1)
        if char in ['\r', '\n']:
            break
        if char == '\x7f':  # Backspace
            if input_chars:
                input_chars.pop()
        else:
            input_chars.append(char)
    
    return ''.join(input_chars)

def join_voice_channel(token, guild_id, channel_id, mute_option, deaf_option):
    ws = WebSocket()
    ws.connect("wss://gateway.discord.gg/?v=9&encoding=json")
    hello = loads(ws.recv())
    heartbeat_interval = hello['d']['heartbeat_interval']
    ws.send(dumps({
        "op": 2,
        "d": {
            "token": token,
            "properties": {
                "$os": "windows",
                "$browser": "Discord",
                "$device": "desktop"
            }
        }
    }))
    ws.send(dumps({
        "op": 4,
        "d": {
            "guild_id": guild_id,
            "channel_id": channel_id,
            "self_mute": mute_option,
            "self_deaf": deaf_option
        }
    }))
    ws.send(dumps({
        "op": 18,
        "d": {
            "type": "guild",
            "guild_id": guild_id,
            "channel_id": channel_id,
            "preferred_region": "singapore"
        }
    }))
    while True:
        sleep(heartbeat_interval / 1000)
        try:
            ws.send(dumps({"op": 1, "d": None}))
        except Exception:
            break

def disconnect_voice_channel(token, guild_id, channel_id):
    ws = WebSocket()
    ws.connect("wss://gateway.discord.gg/?v=9&encoding=json")
    hello = loads(ws.recv())
    ws.send(dumps({
        "op": 2,
        "d": {
            "token": token,
            "properties": {
                "$os": "windows",
                "$browser": "Discord",
                "$device": "desktop"
            }
        }
    }))
    # Disconnect from the voice channel
    ws.send(dumps({
        "op": 4,
        "d": {
            "guild_id": guild_id,
            "channel_id": channel_id,
            "self_mute": False,
            "self_deaf": False
        }
    }))
    while True:
        try:
            ws.send(dumps({"op": 1, "d": None}))
            sleep(heartbeat_interval / 1000)
        except Exception:
            ws.close()
            break

def fetch_tokens(guild_id):
    valid_tokens = []

    # Read tokens from the validtokens.txt file
    with open('../TXTS/validtokens.txt') as file:
        all_tokens = file.read().splitlines()

    for token in all_tokens:
        # Check if the token is valid for the guild_id
        if is_token_valid_for_guild(token, guild_id): 
            valid_tokens.append(token)
            time.sleep(0.1)  # Delay for 1 second between checks

    file_path = f'../TXTS/{guild_id}.txt'

    # Check if the file already exists
    if not os.path.exists(file_path):
        # Save tokens to the file
        with open(file_path, 'w') as file:
            for token in valid_tokens:
                file.write(token + '\n')

    return valid_tokens

# Placeholder function to simulate token validation
def is_token_valid_for_guild(token, guild_id):
    # work in progress too bbg
    return True  # For now, assume all tokens are valid

def main():
    parser = argparse.ArgumentParser(description='Video Conference App')
    parser.add_argument('--all-cameras-on', action='store_true', help='Turn on all cameras')
    args = parser.parse_args()

    yes_responses = ["yes", "y", "yeah", "yep", "sure", "ok", "okay", "yup", "yea", "yah", "uh-huh", "yass", "ok"]
    no_responses = ["no", "n", "nope", "nah", "nay", "not", "never", "none", "nuh-uh"]

    action = gradient_input("join/leave?   ~   ").strip().lower()
    
    if action == "join":
        guild_id = gradient_input("Guild ID   ~   ")
        channel_id = gradient_input("Channel ID   ~   ")
        
        tokens = fetch_tokens(guild_id)

        file_path = f'../TXTS/{guild_id}.txt'

        with open(file_path, 'w') as file:
            for token in tokens:
                file.write(token + '\n')
        
        with open(file_path) as file:
            tokenlist = file.read().splitlines()
        
        mute_option = gradient_input("Mute?   ~   ").strip().lower() in yes_responses
        deaf_option = gradient_input("Deafen?   ~   ").strip().lower() in yes_responses

        executor = ThreadPoolExecutor(max_workers=1000)
        print(print_gradient(f"Joining", (0, 255, 0), (0, 255, 0)))
        
        for i, token in enumerate(tokenlist):
            executor.submit(join_voice_channel, token, guild_id, channel_id, mute_option, deaf_option)

        if args.all_cameras_on:
            for token in tokenlist:
                # also ts doesnt work, im working on the camera
                print(f"Turning on camera for token {token}")

    elif action == "leave":
        guild_id = gradient_input("Guild ID   ~   ")
        channel_id = gradient_input("Channel ID   ~   ")

        tokens = fetch_tokens(guild_id)

        file_path = f'../TXTS/{guild_id}.txt'

        with open(file_path, 'w') as file:
            for token in tokens:
                file.write(token + '\n')
        
        with open(file_path) as file:
            tokenlist = file.read().splitlines()

        executor = ThreadPoolExecutor(max_workers=5000)
        print(print_gradient(f"Leaving", (255, 0, 0), (255, 0, 0)))
        
        # Disconnect all tokens from the voice channel one by one with delay
        for i, token in enumerate(tokenlist):
            executor.submit(disconnect_voice_channel, token, guild_id, channel_id)
            sleep(0.01)  # Sleep for 1 second between each disconnection

    # Wait for all tasks to complete
    executor.shutdown(wait=True)

if __name__ == "__main__":
    main()