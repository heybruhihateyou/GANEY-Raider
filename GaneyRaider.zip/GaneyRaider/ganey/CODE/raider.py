import os
import platform
import sys
import requests
import aiohttp
import asyncio
import random
import string
import configparser
from colorama import init, Fore
import subprocess

# Constants
COOLASS_TITLE = "GANEY"
DISCORD_API_URL = "https://discord.com/api/v9"

# Set console title
os.system("title " + COOLASS_TITLE)

init()

config = configparser.ConfigParser()
config.read("config.ini")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_status(message, color=None):
    colors = {
        Fore.GREEN: (0, 255, 0),
        Fore.RED: (255, 0, 0),
        Fore.YELLOW: (255, 255, 0),
        Fore.BLUE: (0, 0, 255)
    }
    if color in colors:
        print(print_gradient(message, (255, 255, 255), (0, 0, 139)))
    else:
        print(print_gradient(message, (255, 255, 255), (0, 0, 139)))

def print_gradient(text, start_color=(0, 0, 139), end_color=(255, 255, 255)):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color
    length = len(text)
    gradient_text = ""
    for i, char in enumerate(text):
        progress = i / length
        r = int(start_r + (end_r - start_r) * progress)
        g = int(start_g + (end_g - start_g) * progress)
        b = int(start_b + (end_b - start_b) * progress)
        gradient_text += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    return gradient_text

def get_centered_input(prompt):
    prompt = print_gradient(" " * 47 + prompt, (255, 255, 255), (0, 0, 139))
    return input(prompt)

def generate_random_string(length=15):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

async def is_token_valid(session, token, proxy=None):
    url = f"{DISCORD_API_URL}/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    async with session.get(url, headers=headers, proxy=str(proxy) if proxy else None) as response:
        return token if response.status == 200 else None

async def validate_tokens(tokens, proxy=None):
    valid_tokens = set()
    connector = aiohttp.TCPConnector(ssl=False, limit_per_host=1000)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [is_token_valid(session, token, proxy) for token in tokens]
        results = await asyncio.gather(*tasks)
        valid_tokens.update(filter(None, results))

    with open("TXTS/validtokens.txt", "w") as file:
        file.write("\n".join(valid_tokens))

    return list(valid_tokens)

async def send_message(session, token, server_id, channel_id, message, proxy=True):
    headers = {"Authorization": f"{token}", "Content-Type": "application/json"}
    data = {"content": message}

    try:
        async with session.post(f"{DISCORD_API_URL}/channels/{channel_id}/messages", json=data, headers=headers, proxy=str(proxy) if proxy else None) as response:
            success = response.status == 200
            if success:
                print(print_gradient(f"Message sent successfully with token: {token[:10]}...", (255, 255, 255), (0, 0, 139)))
            else:
                print(print_gradient(f"Failed to send message with token: {token[:10]}... (Status: {response.status})", (255, 255, 255), (0, 0, 139)))
            return success
    except Exception as e:
        print(print_gradient(f"Exception occurred sending message with token: {token[:10]}... (Error: {str(e)})", (255, 255, 255), (0, 0, 139)))
        return False

async def send_messages(server_id, channel_id, base_message, tokens, random_string_checkbox, random_ping_checkbox, proxies, thread_count):
    user_ids = await load_user_ids(server_id) if random_ping_checkbox else []  # Load user IDs if random pinging is enabled

    # Limit the number of concurrent requests
    semaphore = asyncio.Semaphore(thread_count)

    async def send_message_with_semaphore(token, message, proxy):
        async with semaphore:
            return await send_message(session, token, server_id, channel_id, message, proxy)

    while True:
        connector = aiohttp.TCPConnector(ssl=False, limit=thread_count)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = []
            for token in tokens:
                message = base_message
                if random_string_checkbox:
                    message += " " + generate_random_string(10)

                if random_ping_checkbox:
                    if user_ids:
                        num_mentions = min(len(user_ids), random.randint(20, 50))
                        mentions = random.sample(user_ids, num_mentions)
                        mention_str = " ".join([f"<@{user_id}>" for user_id in mentions])
                        message += " " + mention_str

                tasks.append(send_message_with_semaphore(token, message, str(random.choice(proxies)) if proxies else None))

            results = await asyncio.gather(*tasks)

async def load_user_ids(server_id):
    with open(f"TXTS/{server_id}.txt", "r") as file:
        return [line.strip() for line in file.readlines()]

async def is_proxy_valid(session, proxy):
    try:
        async with session.get("http://www.google.com", proxy=proxy, timeout=5) as response:
            return response.status == 200
    except Exception:
        return False

async def validate_proxies(proxies):
    valid_proxies = []
    connector = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [is_proxy_valid(session, proxy) for proxy in proxies]
        results = await asyncio.gather(*tasks)
        valid_proxies = [proxy for proxy, is_valid in zip(proxies, results) if is_valid]

    with open("TXTS/valid_proxies.txt", "w") as file:
        file.write("\n".join(valid_proxies))

    return valid_proxies

async def is_token_in_server(session, token, server_id, proxy=True):
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    try:
        async with session.get(f"{DISCORD_API_URL}/guilds/{server_id}/members/@me", headers=headers, proxy=str(proxy) if proxy else None) as response:
            if response.status == 200:
                return True
        
        async with session.get(f"{DISCORD_API_URL}/users/@me/guilds", headers=headers, proxy=str(proxy) if proxy else None) as response:
            if response.status == 200:
                guilds = await response.json()
                return any(guild['id'] == server_id for guild in guilds)
        
        return False
    except Exception as e:
        print(print_gradient(f"Error checking guild membership for token {token[:10]}...: {str(e)}", (255, 255, 255), (0, 0, 139)))
        return False

async def filter_tokens_in_server(tokens, server_id, proxies):
    os.makedirs("SERVERS", exist_ok=True)
    server_tokens_path = f"TXTS/validtokens.txt"
    tokens_in_server = []

    connector = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [is_token_in_server(session, token, server_id, str(random.choice(proxies)) if proxies else None) for token in tokens]
        results = await asyncio.gather(*tasks)
        tokens_in_server.extend(token for token, in_server in zip(tokens, results) if in_server)

    with open(server_tokens_path, "w") as file:
        file.write("\n".join(tokens_in_server))

    print(print_gradient(f"Saved {len(tokens_in_server)} tokens for guild {server_id} to {server_tokens_path}", (255, 255, 255), (0, 0, 139)))

    return tokens_in_server

async def main():
    clear_screen()
    yes_responses = [
        "yes", "y", "yeah", "yep", "sure", "ok", "okay", "yup", "yea", "yah", "uh-huh", "yass", "ok"
    ]
    no_responses = [
        "no", "n", "nope", "nah", "nay", "not", "never", "none", "nuh-uh"
    ]

    use_proxies_input = get_centered_input("Use proxies?   ~   ").strip().lower()
    use_proxies = use_proxies_input in yes_responses

    open_maining_input = get_centered_input("Scrape Ids?   ~   ").strip().lower()
    open_maining = open_maining_input in yes_responses

    random_ping_input = get_centered_input("Random Ping?   ~   ").strip().lower()
    random_ping_checkbox = random_ping_input in yes_responses

    if open_maining:
        subprocess.run(["python", os.path.join(os.path.dirname(__file__), "../Maining.py")])

    if use_proxies:
        try:
            with open("TXTS/valid_proxies.txt", "r") as file:
                proxies = [line.strip() for line in file.readlines()]
        except FileNotFoundError:
            proxies = [
                # proxies like this: "http://proxy:password",
            ]
            proxies = await validate_proxies(proxies)
        else:
            proxies = []

    server_id = get_centered_input("Guild ID   ~   ").strip()
    channel_id = get_centered_input("Channel ID  ~   ").strip()
    base_message = get_centered_input("  Message   ~   ").strip()
    random_string_checkbox_input = get_centered_input("Random String ~   ").strip().lower()
    random_string_checkbox = random_string_checkbox_input in yes_responses

    with open("TXTS/tokens.txt", "r") as file:
        tokens = [line.strip() for line in file.readlines()]

    valid_tokens = await validate_tokens(tokens, proxies if use_proxies else None)

    if valid_tokens:
        thread_count_input = get_centered_input("Amount Of Threads   ~   ").strip()
        thread_count = int(thread_count_input) if thread_count_input.isdigit() else 100  # Default to 100 if not a number

        tokens_in_server = await filter_tokens_in_server(valid_tokens, server_id, proxies if use_proxies else [])

        await send_messages(server_id, channel_id, base_message, tokens_in_server, random_string_checkbox, random_ping_checkbox, proxies if use_proxies else None, thread_count)

def run():
    asyncio.run(main())

if __name__ == "__main__":
    clear_screen()
    run()
