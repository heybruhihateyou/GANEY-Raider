import os
import requests
from concurrent.futures import ThreadPoolExecutor


# Constants
COOL_TITLE = "GANEY"
DISCORD_API_URL = "https://discord.com/api/v9"
INPUT_FILE = "TXTS/tokens.txt"
OUTPUT_FILES = ["TXTS/validtokens.txt", "CODE/validtokens.txt"]

# Set console title
os.system("title " + COOL_TITLE)


def is_token_valid(token):
    url = f"{DISCORD_API_URL}/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return True
    except requests.exceptions.RequestException as e:
        print(f"Error validating token: {e}")
        return False


def validate_token(token):
    if is_token_valid(token):
        print(f"Token {token[:5]}... is valid.")
        return token
    else:
        print(f"Token {token[:5]}... is invalid.")
        return None


def validate_tokens(input_file, output_files):
    if not os.path.exists(input_file):
        print(f"Input file '{input_file}' does not exist. Exiting.")
        return

    try:
        with open(input_file, 'r') as file:
            tokens = file.read().splitlines()
    except OSError as e:
        print(f"Error reading input file: {e}")
        return

    valid_tokens = []

    with ThreadPoolExecutor(max_workers=2000) as executor:
        futures = [executor.submit(validate_token, token) for token in tokens]
        for future in futures:
            valid_token = future.result()
            if valid_token is not None:
                valid_tokens.append(valid_token)

    for output_file in output_files:
        output_dir = os.path.dirname(output_file)
        if not os.path.exists(output_dir):
            try:
                os.makedirs(output_dir)
            except OSError as e:
                print(f"Error creating output directory: {e}")
                continue

        try:
            with open(output_file, 'w') as file:
                for valid_token in valid_tokens:
                    file.write(valid_token + "\n")
        except OSError as e:
            print(f"Error writing to output file: {e}")


if __name__ == "__main__":
    validate_tokens(INPUT_FILE, OUTPUT_FILES)
