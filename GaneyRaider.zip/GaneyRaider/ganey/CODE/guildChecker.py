
# js saying ts is useless



import os
import requests

# Constants
COOL_TITLE = "GANEY"
API_URL = "https://discord.com/api/v9/users/@me/guilds/{guild_id}/member"

os.system("title " + COOL_TITLE)


def print_gradient(text, start_color, end_color):
    """
    Prints text in a gradient color from start_color to end_color.
    """
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color
    length = len(text)
    
    gradient_text = ""
    for i, char in enumerate(text):
        if i < length / 2:
            progress = i / (length / 2)
            r = int(start_r + (255 - start_r) * progress)
            g = int(start_g + (255 - start_g) * progress)
            b = int(start_b + (255 - start_b) * progress)
        else:
            progress = (i - length / 2) / (length / 2)
            r = int(255 - (255 - start_r) * progress)
            g = int(255 - (255 - start_g) * progress)
            b = int(255 - (255 - start_b) * progress)
        
        gradient_text += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    return gradient_text


def check_token_in_guild(token, guild_id):
    """
    Checks if a given token is a member of the specified guild.
    """
    url = API_URL.format(guild_id=guild_id)
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        print(f"Error checking token: {response.status_code} - {response.text}")
        return False


def main():
    """
    Main function to execute the guild token checker.
    """
    tokens_file_path = os.path.join(os.path.dirname(__file__), "..", "TXTS", "validtokens.txt")
    
    try:
        with open(tokens_file_path, "r") as file:
            tokenlist = file.read().splitlines()
    except FileNotFoundError:
        print(print_gradient(f"File not found: {tokens_file_path}", (255, 0, 0), (255, 0, 0)))
        return
    
    guild_id = input(print_gradient("Enter the Guild ID   ~   ", (0, 0, 139), (0, 0, 139)))
    
    tokens_in_guild = [token for token in tokenlist if check_token_in_guild(token, guild_id)]
    
    print(print_gradient(f"Number of tokens in the Guild (Guild ID: {guild_id}): {len(tokens_in_guild)}", (0, 255, 0), (0, 255, 0)))

if __name__ == "__main__":
    main()
