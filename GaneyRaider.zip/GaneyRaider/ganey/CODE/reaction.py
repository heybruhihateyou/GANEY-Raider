import os
import platform
import sys
from os import system
import requests
from concurrent.futures import ThreadPoolExecutor
import ctypes
import asyncio
import subprocess
import random
import aiohttp
import string
import configparser
import time
from colorama import init, Fore, Style
import concurrent.futures

coolasstitle = "GANEY"
system("title " + coolasstitle)

init()

DISCORD_API_URL = "https://discord.com/api/v9"

config = configparser.ConfigParser()
config.read("config.ini")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_gradient(text, start_color=(0, 0, 139), end_color=(0, 0, 139)):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color
    length = len(text)
    
    gradient_text = ""
    for i, char in enumerate(text):
        if i < length / 2:
            progress = i / (length / 2)
            r = int(start_r + (255 - start_r) * progress)
            g = int(start_g + (255 - start_g) * progress)
            b = int(start_b + (255 - start_b) * progress)
        else:
            progress = (i - length / 2) / (length / 2)
            r = int(255 - (255 - start_r) * progress)
            g = int(255 - (255 - start_g) * progress)
            b = int(255 - (255 - start_b) * progress)
        
        gradient_text += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    return gradient_text

def get_centered_input(prompt):
    prompt = " " * 47 + prompt
    gradient_prompt = print_gradient(prompt, (0, 0, 139), (0, 0, 139))  # Dark Blue
    return input(gradient_prompt)

def pick_random_emojis(emojis, count):
    return random.sample(emojis, count)
async def is_token_valid(session, token, proxy=None):
    url = f"{DISCORD_API_URL}/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    async with session.get(url, headers=headers, proxy=str(proxy) if proxy else None) as response:
        return token if response.status == 200 else None

async def validate_tokens(tokens, proxy=None):
    valid_tokens = set()
    connector = aiohttp.TCPConnector(ssl=False, limit_per_host=1000)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [is_token_valid(session, token, proxy) for token in tokens]
        results = await asyncio.gather(*tasks)
        valid_tokens.update(filter(None, results))

    valid_tokens = list(valid_tokens)

    with open("TXTS/tokens.txt", "w") as file:
        file.write("\n".join(valid_tokens))

    with open("TXTS/validtokens.txt", "w") as file:
        file.write("\n".join(valid_tokens))

    return valid_tokens

async def add_reaction(session, token, server_id, channel_id, message_id, emoji, proxy=None):
    headers = {"Authorization": f"{token}", "Content-Type": "application/json"}
    url = f"{DISCORD_API_URL}/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me"

    while True:
        try:
            async with session.put(url, headers=headers, proxy=str(proxy) if proxy else None) as response:
                if response.status == 204:
                    return True
                elif response.status == 403:
                    return False
                elif response.status == 429:
                    retry_after = int(response.headers.get("Retry-After", 1))
                    await asyncio.sleep(0.1)
                    continue
                else:
                    return False
        except Exception as e:
            return False
async def add_reactions(server_id, channel_id, message_id, emojis, tokens, proxies, thread_count):
    print("Adding Reactions")  # Debug statement

    connector = aiohttp.TCPConnector(ssl=False, limit=thread_count)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = []
        for emoji in emojis:
            for token in tokens:
                proxy = str(random.choice(proxies)) if proxies else None
                task = asyncio.create_task(add_reaction(session, token, server_id, channel_id, message_id, emoji, proxy))
                tasks.append(task)
        await asyncio.gather(*tasks)

async def is_proxy_valid(proxy):
    connector = aiohttp.TCPConnector(ssl=False)
    try:
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get("http://www.google.com", proxy=proxy, timeout=5) as response:
                return response.status == 200
    except Exception:
        return False

async def validate_proxies(proxies):
    valid_proxies = []

    def check_proxy(proxy):
        return asyncio.run(is_proxy_valid(proxy))

    with concurrent.futures.ThreadPoolExecutor(max_workers=5000) as executor:
        results = list(executor.map(check_proxy, proxies))

    valid_proxies.extend(proxy for proxy, is_valid in zip(proxies, results) if is_valid)

    with open("TXTS/valid_proxies.txt", "w") as file:
        file.write("\n".join(valid_proxies))

    return valid_proxies

async def main():
    clear_screen()
    yes_responses = [
        "yes", "y", "yeah", "yep", "sure", "ok", "okay", "yup", "yea", "yah", "uh-huh", "yass", "ok"
    ]
    no_responses = [
        "no", "n", "nope", "nah", "nay", "not", "never", "none", "nuh-uh"
    ]

    proxies = []  # Initialize proxies as an empty list

    use_proxies_input = get_centered_input("Use proxies?   ~   ").strip().lower()
    use_proxies = use_proxies_input in yes_responses

    if use_proxies:
        try:
            with open("TXTS/valid_proxies.txt", "r") as file:
                proxies = [line.strip() for line in file.readlines()]
        except FileNotFoundError:
            proxies = [
                # ur proxies should look like this:"http://dfsdsfdsfsdf:passwordithink",
            ]
            proxies = await validate_proxies(proxies)
        else:
            proxies = []

    server_id = get_centered_input("Guild ID   ~   ").strip()
    if not server_id.isdigit():
        print("Invalid Guild ID. Please enter a numeric value.")
        return
    channel_id = get_centered_input("Channel ID  ~   ").strip()
    if not channel_id.isdigit():
        print("Invalid Channel ID. Please enter a numeric value.")
        return
    message_id = get_centered_input("Message ID to react to   ~   ").strip()
    if not message_id.isdigit():
        print("Invalid Message ID. Please enter a numeric value.")
        return

    # List of 50 possible emojis
    emojis = [
        "😊", "😂", "😍", "😒", "😭", "😱", "😎", "😉", "😔", "😢",
        "🤔", "🤗", "😡", "🤩", "🤬", "😷", "🥳", "🤯", "😤", "😧",
        "😬", "😌", "🥺", "😆", "😋", "🤤", "😴", "😳", "😲", "🤫",
        "🤭", "🙃", "😃", "😄", "😇", "😏", "😶", "😋", "🤑", "🤨",
        "🤠", "🧐", "🤥", "🤧", "🥵", "🥶", "🤮", "🤢", "🥱", "💀",
        "👍", "👎", "👏", "🙏", "💪", "🔥", "💯", "⭐",
        "🌟", "✨", "🎉", "🎊", "🚀", "⚡", "🔥"
    ]

    emoji_count_input = get_centered_input("Number of emojis to pick   ~   ").strip()
    try:
        emoji_count = int(emoji_count_input)
        if emoji_count < 1 or emoji_count > len(emojis):
            print(f"Please enter a number between 1 and {len(emojis)}.")
            return
    except ValueError:
        print("Invalid input. Please enter a numeric value.")
        return

    with open("TXTS/tokens.txt", "r") as file:
        tokens = [line.strip() for line in file.readlines()]

    valid_tokens = await validate_tokens(tokens, proxies if use_proxies else None)

    if valid_tokens:
        thread_count_input = get_centered_input("Number of threads to use   ~   ").strip()
        thread_count = int(thread_count_input) if thread_count_input.isdigit() else 100 

        await add_reactions(server_id, channel_id, message_id, pick_random_emojis(emojis, emoji_count), valid_tokens, proxies if use_proxies else None, thread_count)

def run():
    asyncio.run(main())

if __name__ == "__main__":
    clear_screen()
    run()
