import os
import platform
import sys
from os import system
import requests
from concurrent.futures import ThreadPoolExecutor


coolasstitle = "GANEY"
system("title " + coolasstitle)

DISCORD_API_URL = "https://discord.com/api/v9"

def print_gradient(text, start_color=(0, 0, 139), end_color=(0, 0, 139)):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color
    length = len(text)
    
    gradient_text = ""
    for i, char in enumerate(text):
        if i < length / 2:
            progress = i / (length / 2)
            r = int(start_r + (255 - start_r) * progress)
            g = int(start_g + (255 - start_g) * progress)
            b = int(start_b + (255 - start_b) * progress)
        else:
            progress = (i - length / 2) / (length / 2)
            r = int(255 - (255 - start_r) * progress)
            g = int(255 - (255 - start_g) * progress)
            b = int(255 - (255 - start_b) * progress)
        
        gradient_text += f"\033[38;2;{r};{g};{b}m{char}\033[0m"
    return gradient_text

def gradient_input(prompt):
    print(print_gradient(prompt, (0, 0, 139), (0, 0, 139)), end='', flush=True)
    
    input_chars = []
    while True:
        char = sys.stdin.read(1)
        if char in ['\r', '\n']:
            break
        if char == '\x7f':
            if input_chars:
                input_chars.pop()
        else:
            input_chars.append(char)
    
    return ''.join(input_chars)

def clear_screen():
    if platform.system() == "Windows":
        os.system('cls')
    else:
        os.system('clear')

def is_token_valid(token):
    url = f"{DISCORD_API_URL}/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    response = requests.get(url, headers=headers)
    return response.status_code == 200

def validate_token(token):
    if is_token_valid(token):
        print(print_gradient(f"Token {token[:5]}... is valid.", (0, 255, 0), (0, 128, 0)))
        return token
    else:
        print(print_gradient(f"Token {token[:5]}... is invalid.", (255, 0, 0), (128, 0, 0)))
        return None

def validate_tokens(input_file, output_files):
    if not os.path.exists(input_file):
        print(print_gradient(f"Input file '{input_file}' does not exist. Exiting.", (255, 0, 0), (128, 0, 0)))
        return

    with open(input_file, 'r') as file:
        tokens = file.read().splitlines()

    valid_tokens = []

    with ThreadPoolExecutor(max_workers=2000) as executor:
        futures = [executor.submit(validate_token, token) for token in tokens]
        for future in futures:
            valid_token = future.result()
            if valid_token is not None:
                valid_tokens.append(valid_token)

    for output_file in output_files:
        if not os.path.exists(os.path.dirname(output_file)):
            os.makedirs(os.path.dirname(output_file))

        with open(output_file, 'w') as file:
            for valid_token in valid_tokens:
                file.write(valid_token + "\n")

def main():
    while True:
        clear_screen()
        print(print_gradient(r"""
                                      $$$$$$\   $$$$$$\  $$\   $$\ $$$$$$$$\ $$\     $$\ 
                                     $$  __$$\ $$  __$$\ $$$\  $$ |$$  _____|\$$\   $$  |                           
                                     $$ /  \__|$$ /  $$ |$$$$\ $$ |$$ |       \$$\ $$  / 
                                     $$ |$$$$\ $$$$$$$$ |$$ $$\$$ |$$$$$\      \$$$$  /  
                                     $$ |\_$$ |$$  __$$ |$$ \$$$$ |$$  __|      \$$  /   
                                     $$ |  $$ |$$ |  $$ |$$ |\$$$ |$$ |          $$ |    
                                     \$$$$$$  |$$ |  $$ |$$ | \$$ |$$$$$$$$\     $$ |    
                                      \______/ \__|  \__|\__|  \__|\________|    \__|                                                    
        """,(0, 0, 139), (0, 0, 139)))
        print(print_gradient(r"""
       _________________________________________________________________________________________________________
      /                                                                                                         \ 
      |1. Raider                  6. Validate Tokens (required)                                                 |
      |2. Vc Joiner N Leaver      7. Reply Spammer                                                              |
      |3. Token Onliner           8. Reaction Spammer                                                           |
      |4. Nuker                   9. Token Leaver (WIP doesnt work rn)                                          |
      |5. Scrape Ids                                                                                            |
      \_________________________________________________________________________________________________________/ 
     """, (0, 0, 139), (0, 0, 139)))
        choice = gradient_input("   -   ").strip()
        clear_screen()
        if choice == "1":
            os.system("python CODE/raider.py")
        elif choice == "2":
            os.system("python CODE/vc.py")
        elif choice == "3":
            os.system("python CODE/onliner.py")
        elif choice == "4":
            os.system("python CODE/NukeDiscordServer.py")
        elif choice == "5":
            os.system("python Maining.py")
        elif choice == "6":
            input_file = "TXTS/tokens.txt"
            output_files = ["TXTS/validtokens.txt", "CODE/validtokens.txt"]
            validate_tokens(input_file, output_files)
            print(print_gradient("Returning to main menu...", (0, 255, 0), (0, 255, 0)))
        elif choice == "7":
            os.system("python CODE/replier.py")
        elif choice == "8":
            os.system("python CODE/reaction.py")
        elif choice == "exit":
            break
        else:
            print(print_gradient("Invalid Option!", (255, 0, 0), (255, 0, 0)))

if __name__ == "__main__":
    main()
